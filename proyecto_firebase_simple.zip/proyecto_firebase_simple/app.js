// IMPORTACIONES DE FIREBASE
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getFirestore,
  collection,
  addDoc,
  getDocs,
  deleteDoc,
  updateDoc,
  doc
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

// PEGA AQUÍ LA CONFIGURACIÓN QUE TE DA FIREBASE
const firebaseConfig = {
  apiKey: "AIzaSyDRA6bL0bBXAXAHUbvsZZG9_uJK4oXBYPQ",
  authDomain: "registro-aalumnos.firebaseapp.com",
  projectId: "registro-aalumnos",
  storageBucket: "registro-aalumnos.firebasestorage.app",
  messagingSenderId: "294561537492",
  appId: "1:294561537492:web:33505dbea3c30fcc668a41"
};

// CONEXIÓN CON FIREBASE
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const nombre = document.getElementById("nombre");
const edad = document.getElementById("edad");
const carrera = document.getElementById("carrera");
const btnGuardar = document.getElementById("btnGuardar");
const listaAlumnos = document.getElementById("listaAlumnos");

// GUARDAR ALUMNO
btnGuardar.addEventListener("click", async () => {
  if (nombre.value === "" || edad.value === "" || carrera.value === "") {
    alert("Llena todos los campos");
    return;
  }

  await addDoc(collection(db, "alumnos"), {
    nombre: nombre.value,
    edad: edad.value,
    carrera: carrera.value
  });

  nombre.value = "";
  edad.value = "";
  carrera.value = "";

  mostrarAlumnos();
});

// MOSTRAR ALUMNOS
async function mostrarAlumnos() {
  listaAlumnos.innerHTML = "";
  const datos = await getDocs(collection(db, "alumnos"));

  datos.forEach((alumno) => {
    const data = alumno.data();

    listaAlumnos.innerHTML += `
      <div class="alumno">
        <div class="info">
          <b>${data.nombre}</b><br>
          Edad: ${data.edad}<br>
          Carrera/Grupo: ${data.carrera}
        </div>
        <button class="btnEditar" onclick="editarAlumno('${alumno.id}', '${data.nombre}', '${data.edad}', '${data.carrera}')">Editar</button>
        <button class="btnEliminar" onclick="eliminarAlumno('${alumno.id}')">Eliminar</button>
      </div>
    `;
  });
}

// ELIMINAR ALUMNO
window.eliminarAlumno = async function(id) {
  const confirmar = confirm("¿Seguro que quieres eliminar este alumno?");

  if (confirmar) {
    await deleteDoc(doc(db, "alumnos", id));
    mostrarAlumnos();
  }
};

// EDITAR ALUMNO
window.editarAlumno = async function(id, nombreActual, edadActual, carreraActual) {
  const nuevoNombre = prompt("Nuevo nombre:", nombreActual);
  const nuevaEdad = prompt("Nueva edad:", edadActual);
  const nuevaCarrera = prompt("Nueva carrera o grupo:", carreraActual);

  if (nuevoNombre && nuevaEdad && nuevaCarrera) {
    await updateDoc(doc(db, "alumnos", id), {
      nombre: nuevoNombre,
      edad: nuevaEdad,
      carrera: nuevaCarrera
    });

    mostrarAlumnos();
  }
};

mostrarAlumnos();
